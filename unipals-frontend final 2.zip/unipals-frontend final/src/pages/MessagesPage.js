import React, { useEffect, useState } from "react";
import Avatar from "react-avatar";
import { useSelector } from "react-redux";
import ChatBar from "../components/ChatBar/ChatBar";
import ChatBody from "../components/ChatBody/ChatBody";
import ChatFooter from "../components/ChatFooter/ChatFooter";

const MessagesPage = ({ socket }) => {
  const { user, isLoggedIn } = useSelector((state) => state.auth);
  // states for messages, active user and users
  const [messages, setMessages] = useState([]);
  const [activeUser, setActiveUser] = useState();
  const [users, setUsers] = useState([]);

  // on mount, listen to the messageResponse event and newUserResponse event from the server
  useEffect(() => {
    // listen to the messageResponse event from the server
    socket.on("messageResponse", (data) => setMessages([...messages, data]));
    // listen to the newUserResponse event from the server
    socket.on("newUserResponse", (data) => {
      //filter out the user and exclude the self user
      const filteredUsers = data.filter((user) => user.socketID !== socket.id);
      // set the users in the state
      setUsers(filteredUsers);
    });
  }, [socket, messages, users]);

  useEffect(() => {
    // if the user is logged in, emit the newUser event to the server
    if (user && isLoggedIn) {
      // emit the newUser event to the server
      socket.emit("newUser", {
        id: user._id,
        username: user.username,
        name: `${user.firstName} ${user.lastName}`,
        socketID: socket.id,
      });
    }
  }, [socket, user, isLoggedIn]);

  return (
    <div className="flex w-full">
      <ChatBar
        socket={socket}
        activeUser={activeUser}
        setActiveUser={(id) => {
          setActiveUser(id);
        }}
        users={users}
      />
      <div className="w-full relative max-h-screen">
        {activeUser && (
          <div className="sticky top-0 left-0 flex items-center gap-2 py-3 bg-primary text-white px-4">
            <Avatar name={activeUser.name} size="40" round={true} />
            <div>
              <p>{activeUser.name}</p>
              <p>Active now</p>
            </div>
          </div>
        )}
        {activeUser && <ChatBody messages={messages} activeUser={activeUser} />}
        {activeUser && <ChatFooter socket={socket} activeUser={activeUser} />}
        {!activeUser && (
          <div className="flex justify-center items-center w-full h-full">
            <p className="text-2xl font-semibold text-gray-500">
              Select a user to start chatting
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default MessagesPage;
