import axios from "axios";
import React, { useEffect, useState } from "react";
import { Oval } from "react-loader-spinner";
import { useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import { toast } from "react-toastify";
import OthersProfileSection from "../components/OthersProfileSection/OthersProfileSection";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const OtherUsersProfilePage = () => {
  // get the id from the url params
  const { id } = useParams();
  //   // get the token from the redux store
  const { token } = useSelector((state) => state.auth);
  //states for user and posts, and loading
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [posts, setPosts] = useState([]);

  // get the user and posts when the component mounts
  const getUser = async () => {
    // if there is no token, return
    if (!token) {
      return;
    }
    setIsLoading(true);
    // make a request to get the user
    const response = await axios
      .get(`${BACKEND_URL}/users/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .catch((err) => {
        toast.error(err.response.data.message);
        setIsLoading(false);
      });

    // if response is received from the server set the user
    if (response) {
      setUser(response.data.user);
      setIsLoading(false);
    }
  };

  // get the posts of the user
  const getPosts = async () => {
    // if there is no token, return
    if (!token) {
      return;
    }
    setIsLoading(true);
    // make a request to get the posts
    const response = await axios
      .get(`${BACKEND_URL}/posts/user/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .catch((err) => {
        toast.error(err.response.data.message);
        setIsLoading(false);
      });

    // if response is received from the server set the posts
    if (response) {
      setPosts(response.data.posts);
      setIsLoading(false);
    }
  };

  // handler to update the posts array when a post is liked
  const postLikeChangeHandler = (post) => {
    // find the post in the posts array and update it
    const updatedPosts = posts.map((p) => {
      if (p._id === post._id) {
        return post;
      }
      return p;
    });

    setPosts(updatedPosts);
  };

  // call the functions when the component mounts
  useEffect(() => {
    getUser();
    getPosts();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, token]);

  return (
    <div className="px-6 py-10 w-full">
      {!isLoading && (
        <OthersProfileSection
          user={user}
          posts={posts}
          onPostLike={postLikeChangeHandler}
        />
      )}
      {isLoading && (
        <div className="my-3 h-96 flex justify-center items-center">
          <Oval color="#337CAB" height={50} width={50} />
        </div>
      )}
    </div>
  );
};

export default OtherUsersProfilePage;
