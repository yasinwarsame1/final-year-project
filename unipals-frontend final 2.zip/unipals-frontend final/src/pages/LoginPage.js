import axios from "axios";
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { object, string } from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import Button from "../components/Shared/Button/Button";
import { useDispatch } from "react-redux";
import { login } from "../features/auth/authSlice";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const LoginPage = () => {
  // form validation rules
  const validationSchema = object().shape({
    email: string().email("Email is invalid").required("Email is required"),
    password: string()
      .min(6, "Password must be at least 6 characters")
      .required("Password is required"),
  });

  // functions to build form returned by useForm() hook
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
  });

  // get the dispatch function from the redux store
  const dispatch = useDispatch();
  // get the navigate function from the react-router-dom
  const navigate = useNavigate();
  // state to store the loading state
  const [isLoading, setIsLoading] = useState(false);

  // form submit handler
  const formSubmitHandler = async (data) => {
    setIsLoading(true);

    // destructure the data
    const { email, password } = data;
    const body = {
      email,
      password,
    };

    // make the api call to the backend to login the user
    const response = await axios
      .post(`${BACKEND_URL}/users/login`, body)
      .catch((err) => {
        setIsLoading(false);
        toast.error(err.response.data.error);
      });

    // if the response is successful then dispatch the login action
    if (response) {
      setIsLoading(false);
      dispatch(login(response.data));
      toast.success(response.data.message);
      navigate("/");
    }
    setIsLoading(false);
  };

  return (
    <div className="flex justify-center items-center h-[90vh] w-full">
      <form
        className="bg-primary text-white py-10 px-8 rounded-lg shadow-sm min-w-[30vw] mt-8"
        onSubmit={handleSubmit(formSubmitHandler)}
      >
        <h1 className="text-3xl font-[600] text-center">Please Login</h1>
        <div className="flex flex-col gap-3 my-6">
          <label htmlFor="email" className="text-xl font-bold">
            Email:
          </label>
          <input
            type="email"
            id="email"
            className="py-2 px-4 rounded-md focus:outline-none text-black"
            {...register("email")}
          />
          {errors.email && (
            <p className="text-red-500 text-sm">{errors.email.message}</p>
          )}
        </div>
        <div className="flex flex-col gap-3 my-6">
          <label htmlFor="password" className="text-xl font-bold">
            Password:
          </label>
          <input
            type="password"
            id="password"
            className="py-2 px-4 rounded-md focus:outline-none text-black"
            {...register("password")}
          />
          {errors.password && (
            <p className="text-red-500 text-sm">{errors.password.message}</p>
          )}
        </div>
        <div>
          <Button
            type="submit"
            disabled={isLoading}
            className="bg-secondary w-full "
          >
            {isLoading ? "Loading..." : "Login"}
          </Button>
        </div>
        <div className="mt-4 text-center">
          <p>
            Don't have an account?{" "}
            <Link to="/signup" className="font-semibold hover:underline">
              Register
            </Link>
          </p>
        </div>
      </form>
    </div>
  );
};

export default LoginPage;
