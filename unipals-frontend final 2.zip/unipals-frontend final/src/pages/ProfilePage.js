import React from "react";
import ProfileSection from "../components/ProfileSection/ProfileSection";

const ProfilePage = () => {
  return (
    <div className="px-6 py-10 w-full">
      <ProfileSection />
    </div>
  );
};

export default ProfilePage;
