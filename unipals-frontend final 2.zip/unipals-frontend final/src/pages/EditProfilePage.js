import axios from "axios";
import React, { useState } from "react";
import { useSelector } from "react-redux";
import { useForm } from "react-hook-form";
import { object, string } from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { useNavigate } from "react-router-dom";
import MultipleValueTextInput from "react-multivalue-text-input";
import { toast } from "react-toastify";
import Button from "../components/Shared/Button/Button";
import { useDispatch } from "react-redux";
import { updateUser } from "../features/auth/authSlice";

// getting the backend url from the environment variables
const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const EditProfilePage = () => {
  // form validation rules
  const validationSchema = object().shape({
    firstname: string().required("First name is required"),
    lastname: string(),
    // age must be a number between 1 and 100
    age: string()
      .required("Age is required")
      .matches(/^[1-9][0-9]?$|^100$/, {
        message: "Age must be a number between 1 and 100",
      }),
    course: string(),
    address: string(),
  });

  // functions to build form returned by useForm() hook
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
  });

  // get the dispatch function from the redux store
  const { user, token } = useSelector((state) => state.auth);
  // get the dispatch function from the redux store
  const dispatch = useDispatch();
  // get the navigate function from the react-router-dom
  const navigate = useNavigate();
  // state to store the loading state of the form, gender and hobbies
  const [isLoading, setIsLoading] = useState(false);
  const [gender, setGender] = useState(user.gender);
  const [hobbies, setHobbies] = useState(user.hobbies ? user.hobbies : []);

  // form submit handler
  const formSubmitHandler = async (data) => {
    // set the loading state to true
    setIsLoading(true);

    // destructure the data
    const { firstname, lastname, username, age, course, address } = data;

    // create the body object
    const body = {
      firstName: firstname,
      lastName: lastname,
      userName: username,
      age,
      gender,
      hobbies,
      course,
      address,
    };

    // make the api call to the backend to update the user
    const response = await axios
      .put(`${BACKEND_URL}/users/user`, body, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .catch((err) => {
        setIsLoading(false);
        toast.error(err.response.data.error);
      });

    // if the response is successful, update the user in the redux store
    if (response) {
      toast.success(response.data.message);
      dispatch(updateUser(response.data.user));
      navigate("/profile");
      setIsLoading(false);
    }
    // set the loading state to false
    setIsLoading(false);
  };
  return (
    <div className="px-6 py-10 w-full">
      <h1 className="text-3xl font-[600]">Edit Profile</h1>
      <form
        className="py-3 rounded-lg mt-3 flex flex-col gap-4"
        onSubmit={handleSubmit(formSubmitHandler)}
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-2 mt-4">
          <div className="flex flex-col gap-2">
            <label htmlFor="firstname" className="text-xl font-bold">
              First Name:
            </label>
            <input
              type="text"
              id="firstname"
              className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:border-primary"
              defaultValue={user.firstName}
              {...register("firstname")}
            />
            {errors.firstname && (
              <p className="text-xs italic text-red-500">
                {errors.firstname.message}
              </p>
            )}
          </div>
          <div className="flex flex-col gap-2">
            <label htmlFor="lastname" className="text-xl font-bold">
              Last Name:
            </label>
            <input
              type="text"
              id="lastname"
              className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:border-primary"
              defaultValue={user.lastName}
              {...register("lastname")}
            />
            {errors.lastname && (
              <p className="text-xs italic text-red-500">
                {errors.lastname.message}
              </p>
            )}
          </div>
        </div>
        <div className="flex flex-col gap-2">
          <label htmlFor="address" className="text-xl font-bold">
            Address:
          </label>
          <input
            type="text"
            id="address"
            className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:border-primary"
            defaultValue={user.address}
            {...register("address")}
          />
          {errors.address && (
            <p className="text-xs italic text-red-500">
              {errors.address.message}
            </p>
          )}
        </div>
        <div className="flex flex-col gap-2">
          <label htmlFor="course" className="text-xl font-bold">
            Course:
          </label>
          <input
            type="text"
            id="course"
            className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:border-primary"
            defaultValue={user.course}
            {...register("course")}
          />
          {errors.course && (
            <p className="text-xs italic text-red-500">
              {errors.course.message}
            </p>
          )}
        </div>
        <div className="grid grid-cols-2 gap-4 my-2">
          <div className="flex flex-col gap-2">
            <label htmlFor="age" className="text-xl font-bold">
              Age:
            </label>
            <input
              type="number"
              id="age"
              defaultValue={user.age}
              className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:border-primary"
              {...register("age")}
            />
            {errors.age && (
              <p className="text-xs italic text-red-500">
                {errors.age.message}
              </p>
            )}
          </div>
          <div className="flex flex-col gap-2">
            <label htmlFor="gender" className="text-xl font-bold">
              Gender:
            </label>
            {/* select where we can select a gender (male, female, other) */}
            <select
              className="border border-gray-300 rounded-md px-3 py-[10px] focus:outline-none focus:border-primary"
              value={gender}
              onChange={(e) => setGender(e.target.value)}
            >
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </div>
        </div>
        <div className="flex flex-col gap-2">
          <label htmlFor="hobbies" className="text-xl font-bold">
            Hobbies:
          </label>
          <MultipleValueTextInput
            name="hobbies"
            placeholder="Enter your hobbies"
            className={`border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:border-primary`}
            values={hobbies}
            onItemAdded={(item) => setHobbies([...hobbies, item])}
            onItemDeleted={(item) =>
              setHobbies(hobbies.filter((hobby) => hobby !== item))
            }
          />
        </div>
        <div className="mt-6">
          <Button
            type="submit"
            disabled={isLoading}
            className={`bg-[#337CAB] text-white w-40`}
          >
            {isLoading ? "Loading..." : "Update"}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default EditProfilePage;
