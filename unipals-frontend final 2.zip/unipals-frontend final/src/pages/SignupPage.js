import axios from "axios";
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { object, string } from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import Button from "../components/Shared/Button/Button";
import { useDispatch } from "react-redux";
import { login } from "../features/auth/authSlice";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const SignupPage = () => {
  // form validation rules
  const validationSchema = object().shape({
    firstname: string().required("First name is required"),
    lastname: string(),
    username: string().required("Username is required"),
    email: string().email("Email is invalid").required("Email is required"),
    password: string()
      .min(6, "Password must be at least 6 characters")
      .required("Password is required"),
    age: string()
      .required("Age is required")
      .matches(/^[1-9][0-9]?$|^100$/, {
        message: "Age must be a number between 1 and 100",
      }),
  });

  // functions to build form returned by useForm() hook
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
  });

  // get the dispatch function from the redux store
  const dispatch = useDispatch();
  // get the navigate function from the react-router-dom
  const navigate = useNavigate();
  // state to store the loading state
  const [isLoading, setIsLoading] = useState(false);
  // state to store gender state
  const [gender, setGender] = useState("male");

  // form submit handler
  const formSubmitHandler = async (data) => {
    setIsLoading(true);

    // destructure the data
    const { firstname, lastname, username, email, password, age } = data;

    // create the body object
    const body = {
      firstName: firstname,
      lastName: lastname,
      userName: username,
      email,
      password,
      age,
      gender,
    };
    // make the api call to signup the user
    const response = await axios
      .post(`${BACKEND_URL}/users/signup`, body)
      .catch((err) => {
        // if error is received from the server
        setIsLoading(false);
        // display the error message
        toast.error(err.response.data.error);
      });

    // if response is received
    if (response) {
      // display the success message
      toast.success(response.data.message);
      // dispatch the login action
      const { token, user } = response.data;
      dispatch(login({ token, user }));
      navigate("/");
      setIsLoading(false);
    }
    setIsLoading(false);
  };

  return (
    <div className="flex justify-center items-center min-h-[100vh] w-full px-6">
      <form
        className="bg-primary text-white py-6 px-8 rounded-lg shadow-sm min-w-[50vw] mt-8"
        onSubmit={handleSubmit(formSubmitHandler)}
      >
        <h1 className="text-3xl font-[600] text-center">Please Signup</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-2 mt-4">
          <div className="flex flex-col gap-2">
            <label htmlFor="firstname" className="text-xl font-bold">
              First Name:
            </label>
            <input
              type="text"
              id="firstname"
              className="py-2 px-4 rounded-md focus:outline-none text-black"
              {...register("firstname")}
            />
            {errors.firstname && (
              <p className="text-xs italic text-red-500">
                {errors.firstname.message}
              </p>
            )}
          </div>
          <div className="flex flex-col gap-2">
            <label htmlFor="lastname" className="text-xl font-bold">
              Last Name:
            </label>
            <input
              type="text"
              id="lastname"
              className="py-2 px-4 rounded-md focus:outline-none text-black"
              {...register("lastname")}
            />
            {errors.lastname && (
              <p className="text-xs italic text-red-500">
                {errors.lastname.message}
              </p>
            )}
          </div>
        </div>
        <div className="flex flex-col gap-2 my-2">
          <label htmlFor="username" className="text-xl font-bold">
            Username:
          </label>
          <input
            type="text"
            id="username"
            className="py-2 px-4 rounded-md focus:outline-none text-black"
            {...register("username")}
          />
          {errors.username && (
            <p className="text-xs italic text-red-500">
              {errors.username.message}
            </p>
          )}
        </div>
        <div className="flex flex-col gap-2 my-2">
          <label htmlFor="email" className="text-xl font-bold">
            Email:
          </label>
          <input
            type="email"
            id="email"
            className="py-2 px-4 rounded-md focus:outline-none text-black"
            {...register("email")}
          />
          {errors.email && (
            <p className="text-xs italic text-red-500">
              {errors.email.message}
            </p>
          )}
        </div>
        <div className="flex flex-col gap-2 my-2">
          <label htmlFor="password" className="text-xl font-bold">
            Password:
          </label>
          <input
            type="password"
            id="password"
            className="py-2 px-4 rounded-md focus:outline-none text-black"
            {...register("password")}
          />
          {errors.password && (
            <p className="text-xs italic text-red-500">
              {errors.password.message}
            </p>
          )}
        </div>
        <div className="grid grid-cols-2 gap-4 my-2">
          <div className="flex flex-col gap-2">
            <label htmlFor="age" className="text-xl font-bold">
              Age:
            </label>
            <input
              type="number"
              id="age"
              className="py-2 px-4 rounded-md focus:outline-none text-black"
              {...register("age")}
            />
            {errors.age && (
              <p className="text-xs italic text-red-500">
                {errors.age.message}
              </p>
            )}
          </div>
          <div className="flex flex-col gap-2">
            <label htmlFor="gender" className="text-xl font-bold">
              Gender:
            </label>
            {/* select where we can select a gender (male, female, other) */}
            <select
              className="py-2 px-4 rounded-md focus:outline-none text-black"
              value={gender}
              onChange={(e) => setGender(e.target.value)}
            >
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </div>
        </div>
        <div>
          <Button
            type="submit"
            disabled={isLoading}
            className="bg-secondary w-full my-3"
          >
            {isLoading ? "Loading..." : "Signup"}
          </Button>
        </div>
        <div className="mt-2 text-center">
          <p>
            Already have an account?{" "}
            <Link to="/login" className="font-semibold hover:underline">
              Login
            </Link>
          </p>
        </div>
      </form>
    </div>
  );
};

export default SignupPage;
