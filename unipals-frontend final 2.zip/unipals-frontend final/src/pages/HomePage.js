import axios from "axios";
import React, { useEffect, useState } from "react";
import { BsSearch } from "react-icons/bs";
import { Oval } from "react-loader-spinner";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";
import AddNewPost from "../components/AddNewPost/AddNewPost";
import Post from "../components/Post/Post";
import Button from "../components/Shared/Button/Button";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const HomePage = () => {
  // get the token from the redux store
  const { token } = useSelector((state) => state.auth);

  // states for posts, loading, search text, and fetch posts
  const [posts, setPosts] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [fetchPosts, setFetchPosts] = useState(false);

  // get the posts when the component mounts
  const getPosts = async () => {
    // if there is no token, return
    if (!token) {
      return;
    }
    setIsLoading(true);
    // make a request to get the posts of the user
    const response = await axios
      .get(`${BACKEND_URL}/posts/all`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .catch((err) => {
        toast.error(err.response.data.message);
        setIsLoading(false);
      });
    // if response is received from the server set the posts
    if (response) {
      setPosts(response.data.posts);
      setIsLoading(false);
    }
  };

  // function to handle the new post
  const newPostHandler = (post) => {
    setPosts((prevPosts) => [post, ...prevPosts]);
  };

  // function to handle the post like change
  const postLikeChangedHandler = (post) => {
    // find the post in the posts array and update it
    const updatedPosts = posts.map((p) => {
      if (p._id === post._id) {
        return post;
      }
      return p;
    });
    setPosts(updatedPosts);
  };

  // function to handle search and filter the posts
  const searchHandler = async (e) => {
    if (e.key === "Enter" || e.type === "click") {
      // filter the posts array and return the posts that's text contains the search text or the username of the post creator
      const filteredPosts = posts.filter((post) => {
        return (
          post.text.toLowerCase().includes(search.toLowerCase()) ||
          post.user.firstName.toLowerCase().includes(search.toLowerCase()) ||
          post.user.lastName.toLowerCase().includes(search.toLowerCase())
        );
      });
      // set the posts to the filtered posts
      setPosts(filteredPosts);
    }
  };

  // function to handle the search text change
  const searchChangeHandler = (e) => {
    // if the search text is empty, set the fetch posts state to true
    if (e.target.value === "") {
      setFetchPosts((prevState) => !prevState);
    }
    // set the search text
    setSearch(e.target.value);
  };

  // get the posts when the component mounts
  useEffect(() => {
    getPosts();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token, fetchPosts]);

  return (
    <div className="px-6 py-10 w-full">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-[600]">Home Page</h1>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-3 border border-gray-300 rounded-md px-3 py-3 w-fit">
            <BsSearch className="text-xl" />
            <input
              type="text"
              placeholder="Search"
              className="outline-none"
              value={search}
              onChange={searchChangeHandler}
              onKeyDown={searchHandler}
            />
          </div>
          <Button onClick={searchHandler} className="bg-[#337CAB] text-white">
            Search
          </Button>
        </div>
      </div>
      <AddNewPost onAddPost={newPostHandler} />
      {!isLoading && (
        <div className="my-3">
          <h1 className="text-3xl font-[600]">Posts</h1>
          {posts.length > 0 && (
            <div className="my-6 flex flex-col gap-6">
              {posts.map((post) => (
                <Post
                  key={post._id}
                  post={post}
                  onPostLike={postLikeChangedHandler}
                />
              ))}
            </div>
          )}
          {posts.length === 0 && (
            <div className="my-6 flex flex-col gap-6">
              <h1 className="text-2xl font-[600]">No Posts Found</h1>
            </div>
          )}
        </div>
      )}
      {isLoading && (
        <div className="my-3 h-96 flex justify-center items-center">
          <Oval color="#337CAB" height={50} width={50} />
        </div>
      )}
    </div>
  );
};

export default HomePage;
