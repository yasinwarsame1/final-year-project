import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  user: null,
  token: null,
  isLoggedIn: false,
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    login(state, action) {
      // set the user and token in the local storage
      localStorage.setItem("user", JSON.stringify(action.payload.user));
      localStorage.setItem("token", JSON.stringify(action.payload.token));
      // set the user and token in the state
      state.user = action.payload.user;
      state.token = action.payload.token;
      state.isLoggedIn = true;
    },
    logout(state) {
      // remove the user and token from the local storage
      localStorage.removeItem("user");
      localStorage.removeItem("token");
      // remove the user and token from the state
      state.user = null;
      state.token = null;
      state.isLoggedIn = false;
    },
    updateUser(state, action) {
      // update the user in the local storage
      localStorage.setItem("user", JSON.stringify(action.payload));
      // update the user in the state
      state.user = action.payload;
    },
  },
});

export const { login, logout, updateUser } = authSlice.actions;

export default authSlice.reducer;
