import React from "react";
import Avatar from "react-avatar";
import { useNavigate } from "react-router-dom";

const UserSuggestions = ({ suggestions }) => {
  const navigate = useNavigate();

  return (
    <div>
      <h1 className="text-xl font-bold">Suggestions</h1>
      <div className="flex flex-col gap-4 mt-4">
        {/* // map through the suggestions and render the user */}
        {suggestions.map((user) => (
          <div
            className="flex items-center gap-2 cursor-pointer"
            onClick={() => navigate(`/profile/${user._id}`)}
            key={user._id}
          >
            <Avatar
              name={`${user.firstName} ${user.lastName}`}
              size="40"
              round={10}
            />
            <div>
              <h1 className="text-md font-bold">
                {user?.firstName} {user?.lastName}
              </h1>
              <p className="text-sm">@{user?.userName}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default UserSuggestions;
