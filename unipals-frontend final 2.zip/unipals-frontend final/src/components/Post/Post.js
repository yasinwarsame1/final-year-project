import axios from "axios";
import moment from "moment/moment";
import React, { useState } from "react";
import Avatar from "react-avatar";
import { AiOutlineLike, AiOutlineComment, AiFillLike } from "react-icons/ai";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const Post = ({ post, onPostLike }) => {
  // get the token from the redux store
  const { user, token } = useSelector((state) => state.auth);
  const navigate = useNavigate();

  // check if the post is liked by the user or not
  const [isLiked, setIsLiked] = useState(
    post.likes.find((like) => like.user === user._id)
  );

  const [showComments, setShowComments] = useState(false);

  const [comment, setComment] = useState("");

  // function to like or unlike a post
  const likeHandler = async () => {
    // if the post is liked by the user, unlike it
    if (isLiked) {
      const response = await axios
        .put(
          `${BACKEND_URL}/posts/unlike/${post._id}`,
          {},
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        )
        .catch((err) => {
          toast.error(err.response.data.message);
        });
      if (response) {
        toast.success(response.data.message);
        onPostLike(response.data.post);
        setIsLiked(false);
      }
    } else {
      const response = await axios
        .put(
          `${BACKEND_URL}/posts/like/${post._id}`,
          {},
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        )
        .catch((err) => {
          toast.error(err.response.data.message);
        });
      if (response) {
        toast.success(response.data.message);
        onPostLike(response.data.post);
        setIsLiked(true);
      }
    }
  };

  const commentPostHandler = async (e) => {
    //check if the user has pressed enter key or clicked on the button
    if (e.key === "Enter" || e.type === "click") {
      const response = await axios
        .put(
          `${BACKEND_URL}/posts/comment/${post._id}`,
          { text: comment },
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        )
        .catch((err) => {
          toast.error(err.response.data.message);
        });
      if (response) {
        toast.success(response.data.message);
        onPostLike(response.data.post);
        setComment("");
      }
    }
  };

  return (
    <div className="bg-gray-100 px-6 py-4 rounded-lg">
      <div
        className="flex gap-2 items-center cursor-pointer"
        onClick={() => navigate(`/profile/${post.user._id}`)}
      >
        <Avatar
          name={`${post.user.firstName} ${post.user.lastName}`}
          size="50"
          round={10}
        />
        <h1 className="text-lg font-[600]">
          {post.user.firstName + " " + post.user.lastName}
        </h1>
      </div>
      <div className="my-6">
        <p>{post.text}</p>
      </div>
      {post.image && (
        <div className="my-4 flex justify-start items-center">
          <img src={post.image} alt="post" className="h-96 object-contain" />
        </div>
      )}
      <div className="flex justify-between items-center border-t border-t-gray-300 pt-4">
        <div
          className="flex items-center gap-2 cursor-pointer"
          onClick={likeHandler}
        >
          {/* // if the post is not liked by the user, show the outline like icon */}
          {!isLiked && <AiOutlineLike className="text-2xl" />}
          {/* // if the post is liked by the user, show the filled like icon */}
          {isLiked && <AiFillLike className="text-2xl text-primary" />}
          <span>{post.likes.length} Likes</span>
        </div>
        <div
          className="flex items-center gap-2 cursor-pointer"
          onClick={() => setShowComments((prevState) => !prevState)}
        >
          {/* // if the comments are not shown, show the outline comment icon */}
          {!showComments && <AiOutlineComment className="text-2xl" />}
          {/* // if the comments are shown, show the filled comment icon */}
          {showComments && (
            <AiOutlineComment className="text-2xl text-primary" />
          )}
          <span>{post.comments.length} Comments</span>
        </div>
        <div>
          <p className="">{moment(post.createdAt).fromNow()}</p>
        </div>
      </div>
      {/* add comments section input */}
      <div className="mt-4 border-t border-t-gray-300 flex flex-col gap-1 pt-4">
        <div className="flex gap-2 items-center justify-between my-2">
          <div className="flex items-center gap-2 flex-1">
            <Avatar
              name={`${user.firstName} ${user.lastName}`}
              size="40"
              round={10}
            />
            <div className="flex flex-col w-full">
              <h1 className="text-sm font-[600]">
                {user.firstName + " " + user.lastName}
              </h1>
              <input
                type="text"
                placeholder="Write a comment..."
                className="bg-transparent outline-none text-sm"
                onKeyDown={commentPostHandler}
                value={comment}
                onChange={(e) => setComment(e.target.value)}
              />
            </div>
          </div>
          <div>
            <button
              className="bg-primary text-white px-4 py-1 rounded-lg"
              onClick={commentPostHandler}
            >
              Post
            </button>
          </div>
        </div>
      </div>
      {/* comments section */}
      {/* // if the comments are shown, show the comments */}
      {showComments && (
        <div
          className="mt-4 border-t border-t-gray-300 flex flex-col gap-1 pt-4 max-h-56 overflow-y-scroll pr-4"
          id="comment-section"
        >
          {/* // if the post has comments, show the comments else show a message */}
          {post.comments.length > 0 &&
            post.comments.map((comment) => (
              // map through the comments and show the comment for each comment
              <div
                className="flex gap-2 items-center justify-between my-2"
                key={comment._id}
              >
                <div className="flex items-center gap-2">
                  <Avatar
                    name={`${comment.user.firstName} ${comment.user.lastName}`}
                    size="40"
                    round={10}
                  />
                  <div className="flex flex-col">
                    <h1 className="text-sm font-[600]">
                      {comment.user.firstName + " " + comment.user.lastName}
                    </h1>
                    <p className="text-sm">{comment.text}</p>
                  </div>
                </div>
                <div>
                  <p className="text-sm">
                    {moment(comment.createdAt).fromNow()}
                  </p>
                </div>
              </div>
            ))}
          {post.comments.length === 0 && (
            <div className="flex justify-center items-center">
              <p className="text-gray-500">No comments yet</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default Post;
