import axios from "axios";
import React, { useEffect, useState } from "react";
import {
  AiOutlineHome,
  AiOutlineMessage,
  AiOutlineLogin,
  AiOutlineLogout,
} from "react-icons/ai";
import { BsPerson, BsPersonAdd } from "react-icons/bs";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { logout } from "../../features/auth/authSlice";
import UserSuggestions from "../UserSuggestions/UserSuggestions";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const Sidebar = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  // get the token from the redux store
  const { isLoggedIn, token } = useSelector((state) => state.auth);

  // state to store the user suggestions
  const [suggestions, setSuggestions] = useState([]);

  // function to logout the user and clear the token from the redux store
  const logoutHandler = () => {
    dispatch(logout());
    toast.success("Logged out successfully");
    navigate("/login");
  };
  // function to get the user suggestions
  const getUserSuggestions = async () => {
    // if the token is not present, return
    if (!token) return;
    // make a get request to the backend to get the user suggestions
    const response = await axios
      .get(`${BACKEND_URL}/users/get-suggestions`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .catch((err) => {
        // if there is an error, show the error message
        toast.error(err.response.data.message);
      });

    // if the response is successful, set the suggestions
    if (response) {
      setSuggestions(response.data.users);
    }
  };

  // get the user suggestions on component mount and unmount and when the token changes
  useEffect(() => {
    getUserSuggestions();

    return () => {
      setSuggestions([]);
    };

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  return (
    <div>
      <div className="bg-primary py-4 px-3 fixed w-64 text-white h-full">
        <h1 className="text-3xl font-[700]">UniPals</h1>
        <div className="my-4 py-6 flex flex-col gap-10 border-t-2 border-t-gray-200">
          {isLoggedIn && (
            <Link
              to="/"
              className="flex items-center gap-2 text-2xl transition-all duration-300 ease-in hover:text-gray-100"
            >
              <AiOutlineHome />
              Home
            </Link>
          )}
          {isLoggedIn && (
            <Link
              to="/messages"
              className="flex items-center gap-2 text-2xl transition-all duration-300 ease-in hover:text-gray-100"
            >
              <AiOutlineMessage />
              Messages
            </Link>
          )}
          {/* // if the user is logged in, show the profile link, else show the login and signup links */}
          {isLoggedIn && (
            <Link
              to="/profile"
              className="flex items-center gap-2 text-2xl transition-all duration-300 ease-in hover:text-gray-100"
            >
              <BsPerson />
              Profile
            </Link>
          )}
          {/* // if the user is not logged in, show the login and signup links */}
          {!isLoggedIn && (
            <Link
              to="/login"
              className="flex items-center gap-2 text-2xl transition-all duration-300 ease-in hover:text-gray-100"
            >
              <AiOutlineLogin />
              Login
            </Link>
          )}
          {!isLoggedIn && (
            <Link
              to="/signup"
              className="flex items-center gap-2 text-2xl transition-all duration-300 ease-in hover:text-gray-100"
            >
              <BsPersonAdd />
              Signup
            </Link>
          )}
          {isLoggedIn && (
            <button
              className="flex items-center gap-2 text-2xl transition-all duration-300 ease-in hover:text-gray-100"
              onClick={logoutHandler}
            >
              <AiOutlineLogout />
              Logout
            </button>
          )}
        </div>
        {suggestions && suggestions.length > 0 && (
          <UserSuggestions suggestions={suggestions} />
        )}
      </div>
      <div className="w-64"></div>
    </div>
  );
};

export default Sidebar;
