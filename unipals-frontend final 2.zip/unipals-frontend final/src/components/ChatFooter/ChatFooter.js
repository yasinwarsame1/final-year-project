import React, { useState } from "react";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";
import Button from "../Shared/Button/Button";

const ChatFooter = ({ socket, activeUser }) => {
  // get the user from the redux store
  const { user } = useSelector((state) => state.auth);

  // state for message
  const [message, setMessage] = useState("");

  // function to handle the send message
  const sendMessageHandler = (e) => {
    // check if enter key is pressed or send button is clicked
    if (e.key === "Enter" || e.type === "click") {
      // check if message is not empty
      if (message.trim().length === 0) {
        return toast.error("Message cannot be empty");
      }
      // send message to server
      socket.emit("message", {
        text: message,
        name: `${user.firstName} ${user.lastName}`,
        from: user._id,
        to: activeUser.id,
        socketID: socket.id,
      });
      // clear message
      setMessage("");
    }
  };

  return (
    <div className="absolute left-0 bottom-0 py-3 w-full px-8">
      <div className="flex gap-3 items-center">
        <input
          type="text"
          placeholder="Type a message"
          className={`w-full h-12 rounded-md border border-gray-300 px-4 py-2 focus:outline-none focus:border-primary`}
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={sendMessageHandler}
        />
        <Button className={`w-36`} onClick={sendMessageHandler}>
          Send
        </Button>
      </div>
    </div>
  );
};

export default ChatFooter;
