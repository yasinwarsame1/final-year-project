import axios from "axios";
import React, { useRef, useState } from "react";
import Avatar from "react-avatar";
import { TbPhotoPlus } from "react-icons/tb";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";
import Button from "../Shared/Button/Button";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const AddNewPost = ({ onAddPost }) => {
  // get the token from the redux store
  const { token, user } = useSelector((state) => state.auth);

  // states for image, content, text, and loading
  const imageInputRef = useRef();
  const [image, setImage] = useState();
  const [content, setContent] = useState();
  const [text, setText] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // function to handle the image change
  const handleImageChange = (e) => {
    if (e.target.files[0]) {
      // set the image and content
      setImage(URL.createObjectURL(e.target.files[0]));
      setContent(e.target.files[0]);
    }
  };

  // function to handle the new post
  const newPostHandler = async () => {
    setIsLoading(true);
    // create a form data object
    const formData = new FormData();
    formData.append("image", content);
    formData.append("text", text);
    // make a request to create a new post
    const response = await axios
      .post(`${BACKEND_URL}/posts/create`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      })
      .catch((err) => {
        toast.error(err.response.data.message);
        setIsLoading(false);
      });

    // if response is received from the server, show a success message and add the post to the posts array
    if (response) {
      toast.success(response.data.message);
      setIsLoading(false);
      onAddPost(response.data.post);
    }
    setIsLoading(false);
    setText("");
    setImage(null);
    setContent(null);
  };

  return (
    <div className="flex gap-4 my-6">
      <div>
        <Avatar
          name={`
          ${user?.firstName} ${user?.lastName}
        `}
          size="50"
          round={10}
        />
      </div>
      <div className="bg-gray-100 py-4 px-6 w-full rounded-lg">
        <textarea
          placeholder="Tell us what's been on your mind recently?"
          className="bg-gray-100 w-full focus:outline-none max-h-[40vh] min-h-[10vh]"
          style={{ resize: "none" }}
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        {image && (
          <div className="my-4 flex justify-start items-center">
            <img src={image} alt="post" className="h-96 object-contain" />
          </div>
        )}
        <input
          type="file"
          onChange={handleImageChange}
          ref={imageInputRef}
          className="opacity-0"
        />
        <div className="flex items-center gap-3">
          <Button
            className="text-white flex items-center gap-2 w-fit bg-[#337CAB]"
            // when the button is clicked, it will trigger the click event on the input element
            onClick={() => imageInputRef.current.click()}
            disabled={isLoading}
          >
            Upload an Image
            <TbPhotoPlus className="text-2xl" />
          </Button>
          <Button
            className="text-white w-28 bg-[#337CAB]"
            onClick={newPostHandler}
            disabled={isLoading}
          >
            Post
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AddNewPost;
