import React from "react";
import { useSelector } from "react-redux";
import OtherUserMessage from "./OtherUserMessage";
import SelfMessage from "./SelfMessage";

const ChatBody = ({ messages, activeUser }) => {
  // get the logged in user from the redux store
  const { user } = useSelector((state) => state.auth);

  return (
    <div className="max-h-[80%] overflow-y-auto px-4 py-4" id="chat-body">
      {messages.length > 0 &&
        messages.map((message) => {
          //check if the message is between the active user and the logged in user
          if (
            (message.from === user._id && message.to === activeUser.id) ||
            (message.from === activeUser.id && message.to === user._id)
          ) {
            // if the message is from the logged in user, render the SelfMessage component
            return message.from === user._id ? (
              <SelfMessage key={message._id} message={message} />
            ) : (
              // if the message is from the other user, render the OtherUserMessage component
              <OtherUserMessage key={message._id} message={message} />
            );
          }
        })}
      {/* // if the messages array is empty, render the no messages yet message */}
      {messages.length === 0 && (
        <div className="flex justify-center items-center h-full">
          <p className="text-gray-500">No messages yet</p>
        </div>
      )}
    </div>
  );
};

export default ChatBody;
