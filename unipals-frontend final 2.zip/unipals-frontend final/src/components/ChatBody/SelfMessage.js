import React from "react";
import Avatar from "react-avatar";

const SelfMessage = ({ message }) => {
  return (
    // render the message from the logged in user
    <div className="flex justify-end my-4">
      <div className="flex items-center gap-2">
        <Avatar name={message.name} size="40" round={true} />
        <div className="bg-primary rounded-lg p-2">
          <p className="text-white">{message.text}</p>
        </div>
      </div>
    </div>
  );
};

export default SelfMessage;
