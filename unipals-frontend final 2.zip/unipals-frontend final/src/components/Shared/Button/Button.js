import React from "react";

const Button = ({
  className,
  children,
  type = "button",
  disabled,
  onClick,
}) => {
  return (
    <button
      className={`bg-primary text-white py-3 px-4 rounded-md font-semibold transition-all duration-200 ease-linear hover:opacity-90 disabled:opacity-25 disabled:cursor-not-allowed ${className}`}
      type={type}
      disabled={disabled}
      onClick={onClick}
    >
      {children}
    </button>
  );
};

export default Button;
