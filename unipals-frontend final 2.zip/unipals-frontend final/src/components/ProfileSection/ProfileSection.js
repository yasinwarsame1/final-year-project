import axios from "axios";
import React, { useEffect, useState } from "react";
import Avatar from "react-avatar";
import { Oval } from "react-loader-spinner";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import Post from "../Post/Post";
import Button from "../Shared/Button/Button";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const ProfileSection = () => {
  const navigate = useNavigate();

  // get the token from the redux store
  const { user, token } = useSelector((state) => state.auth);
  const [isLoading, setIsLoading] = useState(false);
  const [posts, setPosts] = useState([]);

  // get the posts of the user
  const getPosts = async () => {
    setIsLoading(true);
    if (!token) {
      return;
    }
    // make a request to get the posts of the user
    const response = await axios
      .get(`${BACKEND_URL}/posts/user`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .catch((err) => {
        toast.error(err.response.data.message);
        setIsLoading(false);
      });

    // if response is received from the server set the posts
    if (response) {
      setPosts(response.data.posts);
      setIsLoading(false);
    }
  };

  const postLikeChangedHandler = (post) => {
    // find the post in the posts array and update it
    const updatedPosts = posts.map((p) => {
      if (p._id === post._id) {
        return post;
      }
      return p;
    });
    setPosts(updatedPosts);
  };

  // get the posts when the component mounts
  useEffect(() => {
    getPosts();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  return (
    <>
      {/* // if the user is there then show the profile */}
      {user && (
        <div>
          <h1 className="text-3xl font-[600]">Profile</h1>
          <div className="flex justify-between items-center gap-4">
            <div className="my-6 flex gap-3 items-center">
              <div>
                <Avatar
                  name={`${user?.firstName} ${user?.lastName}`}
                  size="80"
                  round={10}
                />
              </div>
              <div>
                <h1 className="text-2xl">
                  {user?.firstName} {user?.lastName}
                </h1>
                <p className="font-[600]">@{user?.userName}</p>
              </div>
            </div>
            <Button
              className="text-white w-28"
              onClick={() => navigate("/profile/edit")}
            >
              Edit
            </Button>
          </div>
          <div className="my-3">
            <h1 className="text-2xl font-[600] my-4 underline">About you</h1>
            <div className="grid grid-cols-3 gap-4 w-full mt-6">
              <div className="text-lg flex items-center gap-2">
                <h3 className="font-[600]">First Name:</h3>
                <p>{user?.firstName}</p>
              </div>
              <div className="text-lg flex items-center gap-2">
                <h3 className="font-[600]">Last Name:</h3>
                <p>{user?.lastName}</p>
              </div>
              <div className="text-lg flex items-center gap-2">
                <h3 className="font-[600]">User Name:</h3>
                <p className="break-all">{user?.userName}</p>
              </div>
              <div className="text-lg flex items-center gap-2">
                <h3 className="font-[600]">Email:</h3>
                <p className="break-all">{user?.email}</p>
              </div>
              <div className="text-lg flex items-center gap-2">
                <h3 className="font-[600]">Age:</h3>
                <p>{user?.age}</p>
              </div>
              <div className="text-lg flex gap-2">
                <h3 className="font-[600]">Address:</h3>
                <p>{user?.address === "" ? "Not Specified" : user?.address}</p>
              </div>
              <div className="text-lg flex items-center gap-2">
                <h3 className="font-[600]">Course:</h3>
                <p>{user?.course === "" ? "Not Specified" : user?.course}</p>
              </div>
              <div className="text-lg flex items-center gap-2">
                <h3 className="font-[600]">Gender:</h3>
                <p>{user?.gender}</p>
              </div>
            </div>
          </div>
          <div className="py-2">
            <h1 className="text-2xl font-[600] my-4 underline">Hobbies</h1>
            <div>
              {/* // if the user has no hobbies then show the message */}
              {user?.hobbies.length === 0 ? (
                <p className="text-lg">No hobbies added</p>
              ) : (
                // else show the hobbies
                <div className="grid grid-cols-4 gap-4 w-full mt-6">
                  {user.hobbies.map((hobby, index) => (
                    <div className="text-lg flex items-center gap-2 bg-gray-100 py-2 px-4">
                      <h3 className="font-[600]">
                        {index + 1}
                        {")"}. {hobby}
                      </h3>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
          {/* // if the posts are not loading then show the posts */}
          {!isLoading && posts && (
            <div className="py-2">
              <h1 className="text-2xl font-[600] my-4 underline">
                Recent Posts
              </h1>
              <div>
                {/* // if the user has no posts then show the message */}
                {posts.length === 0 ? (
                  <p className="text-lg">No posts added</p>
                ) : (
                  // else show the posts
                  <div className="flex flex-col gap-4 w-full mt-6">
                    {posts.map((post) => (
                      <Post
                        key={post._id}
                        post={post}
                        onPostLike={postLikeChangedHandler}
                      />
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
          {isLoading && (
            <div className="my-3 h-96 flex justify-center items-center">
              <Oval color="#337CAB" height={50} width={50} />
            </div>
          )}
        </div>
      )}
    </>
  );
};

export default ProfileSection;