import React from "react";
import Avatar from "react-avatar";

const UserItem = ({ activeUser, user, setActiveUser }) => {
  return (
    // if the active user is the same as the user, add the bg-primary and text-white classes
    <div
      className={`
        flex items-center gap-4 p-2 rounded-lg cursor-pointer
        ${
          activeUser?.id === user.id
            ? "bg-primary text-white"
            : "hover:bg-gray-100"
        }
    `}
      onClick={() => setActiveUser(user)}
    >
      <Avatar name={user.name} size="40" round={true} />
      <div>
        <p>{user.name}</p>
        <p>Active now</p>
      </div>
    </div>
  );
};

export default UserItem;
