import React from "react";
import UserItem from "./UserItem";

const ChatBar = ({ setActiveUser, activeUser, users }) => {
  return (
    <div className="bg-gray-200 h-screen w-80 py-6 px-3">
      <h1 className="text-2xl font-semibold">Active Users</h1>
      {users.length > 0 && (
        <div className="my-4 py-6 flex flex-col gap-4 border-t-2 border-t-secondary">
          {/* map through the users and render the UserItem component */}
          {users.map((user) => (
            <UserItem
              key={user.id}
              user={user}
              activeUser={activeUser}
              setActiveUser={(id) => setActiveUser(id)}
            />
          ))}
        </div>
      )}
      {/* if the users array is empty, render the no users online message */}
      {users.length === 0 && (
        <div className="py-4">
          <p className="text-gray-500">No users online</p>
        </div>
      )}
    </div>
  );
};

export default ChatBar;
