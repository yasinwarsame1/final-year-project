import React, { useEffect } from "react";
import socketIO from "socket.io-client";
import { useDispatch, useSelector } from "react-redux";
import { Routes, Route, useNavigate } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Sidebar from "./components/Sidebar/Sidebar";
import { login, logout } from "./features/auth/authSlice";
import EditProfilePage from "./pages/EditProfilePage";
import HomePage from "./pages/HomePage";
import LoginPage from "./pages/LoginPage";
import MessagesPage from "./pages/MessagesPage";
import OtherUsersProfilePage from "./pages/OtherUsersProfilePage";
import ProfilePage from "./pages/ProfilePage";
import SignupPage from "./pages/SignupPage";

// making a connection with the socket server
const socket = socketIO.connect(process.env.REACT_APP_SERVER_URL);

function App() {
  // get the isLoggedIn and user from the redux store
  const { isLoggedIn } = useSelector((state) => state.auth);
  // get the dispatch function from the redux store
  const dispatch = useDispatch();
  // get the navigate function from the react-router-dom
  const navigate = useNavigate();

  useEffect(() => {
    // fetch the user data from the local storage and set it in the redux store
    const user = JSON.parse(localStorage.getItem("user"));
    const token = JSON.parse(localStorage.getItem("token"));
    if (user && token) {
      // dispatch the action to set the user and token in the redux store
      dispatch(login({ user, token }));
    } else {
      // dispatch the action to remove the user and token from the redux store
      dispatch(logout());
    }
  }, [dispatch]);

  useEffect(() => {
    // if the user is not logged in, navigate to the login page
    if (!isLoggedIn) {
      navigate("/login");
    }
    // if the user is logged in, navigate to the home page
    if (isLoggedIn) {
      navigate("/");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isLoggedIn]);

  return (
    <div className="flex">
      <ToastContainer />
      <Sidebar />
      <Routes>
        {isLoggedIn && <Route path="/" element={<HomePage />} />}
        {isLoggedIn && (
          <Route path="/messages" element={<MessagesPage socket={socket} />} />
        )}
        {isLoggedIn && <Route path="/profile" element={<ProfilePage />} />}
        {isLoggedIn && (
          <Route path="/profile/:id" element={<OtherUsersProfilePage />} />
        )}
        {isLoggedIn && (
          <Route path="/profile/edit" element={<EditProfilePage />} />
        )}
        {!isLoggedIn && <Route path="/login" element={<LoginPage />} />}
        {!isLoggedIn && <Route path="/signup" element={<SignupPage />} />}
      </Routes>
    </div>
  );
}

export default App;
