const express = require("express");
const multer = require("multer");
const { v4: uuidv4 } = require("uuid");

const router = express.Router();

const postController = require("../controllers/post-controller");
const verifyAuth = require("../middleware/auth");

// setting up the storage for multer
const DIR = "./uploads/";
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, DIR);
  },
  filename: (req, file, cb) => {
    const fileName = file.originalname.toLowerCase().split(" ").join("-"); // to remove spaces from file name
    cb(null, uuidv4() + "-" + fileName); // to add unique id to file name
  },
});

// setting up the file filter for multer
const upload = multer({
  storage: storage,
  fileFilter: (req, file, cb) => {
    if (
      file.mimetype == "image/png" ||
      file.mimetype == "image/jpg" ||
      file.mimetype == "image/jpeg"
    ) {
      cb(null, true);
    } else {
      cb(null, false);
      return cb(new Error("Only .png, .jpg and .jpeg format allowed!"));
    }
  },
});

// router to handle post creation
router.post(
  "/create",
  verifyAuth,
  upload.single("image"),
  postController.createPost
);

// router to handle post like
router.put("/like/:id", verifyAuth, postController.likePost);

// router to handle post unlike
router.put("/unlike/:id", verifyAuth, postController.unlikePost);

// router to handle post comment
router.put("/comment/:id", verifyAuth, postController.commentPost);

// router to get all posts
router.get("/all", verifyAuth, postController.getAllPosts);

// router to get posts of a user
router.get("/user", verifyAuth, postController.getUserPosts);

// router to get a post
router.get("/:id", verifyAuth, postController.getPost);

// router to get posts of a user by id
router.get("/user/:id", verifyAuth, postController.getUserPostsById);

module.exports = router;
