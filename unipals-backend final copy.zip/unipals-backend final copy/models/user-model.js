const mongoose = require("mongoose");

// Create a schema for users
const userSchema = new mongoose.Schema(
  {
    firstName: {
      type: String,
      required: true,
    },
    lastName: {
      type: String,
      default: "",
    },
    userName: {
      type: String,
      required: true,
      unique: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    password: {
      type: String,
      required: true,
    },
    address: {
      type: String,
      default: "",
    },
    age: {
      type: Number,
      required: true,
    },
    course: {
      type: String,
      default: "",
    },
    gender: {
      type: String,
      enum: ["male", "female", "other"],
      required: true,
    },
    hobbies: {
      type: [String],
      default: [],
    },
  },
  { timestamps: true }
);

// Create a model for users
const User = mongoose.model("User", userSchema);

module.exports = User;
