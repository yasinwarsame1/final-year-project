// requiring the dotenv package
require("dotenv").config();
// requiring the database connection
require("./config/db").connect();

const express = require("express");
const cors = require("cors");

// requiring the routes
const userRoutes = require("./routes/user-routes");
const postRoutes = require("./routes/post-routes");

// getting the port from the environment variables
const PORT = process.env.PORT || 4000;

const app = express();
const http = require("http").Server(app);

app.use(express.json());
app.use(cors());

// socket.io configuration
const socketIO = require("socket.io")(http, {
  cors: {
    origin: "*",
  },
});

// list of users
let users = [];

// socket.io connection
socketIO.on("connection", (socket) => {
  console.log("🔥: A user connected");
  // emits the list of users to the client
  socketIO.emit("newUserResponse", users);

  // listens when a user sends a message
  socket.on("message", (data) => {
    console.log("🔥: A message was sent");
    console.log(data);
    // emits the message to the client
    socketIO.emit("messageResponse", data);
  });

  //Listens when a new user joins the server
  socket.on("newUser", (data) => {
    console.log("🔥: A new user joined");
    console.log(data);
    // check if the user is already in the list of users
    const userExists = users.find((user) => user.id === data.id);
    // if the user is already in the list of users, then update the socket id
    if (userExists) {
      userExists.socketID = socket.id;
    } else {
      // if the user is not in the list of users, then add the user to the list of users
      users.push(data);
    }
    //Sends the list of users to the client
    socketIO.emit("newUserResponse", users);
  });

  socket.on("disconnect", () => {
    console.log("🔥: A user disconnected");
    //Updates the list of users when a user disconnects from the server
    users = users.filter((user) => user.socketID !== socket.id);
    // console.log(users);
    //Sends the list of users to the client
    socketIO.emit("newUserResponse", users);
    socket.disconnect();
  });
});

// route to check if the api is running
app.get("/", (req, res) => {
  res.send("Api is running...");
});

//serve the static files of uploads folder
app.use("/uploads", express.static("uploads"));

// using the routes
app.use("/api/users", userRoutes);
app.use("/api/posts", postRoutes);

// starting the server
http.listen(PORT, () => {
  console.log("Server is running on port 5000");
});
