const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const User = require("../models/user-model");

const signup = async (req, res) => {
  try {
    // Get user input
    const { firstName, lastName, userName, email, password, age, gender } =
      req.body;


    // Validate user input
    if (!(email && password && firstName && userName)) {
      res.status(400).send({ error: "All input is required" });
    }

    // Check if user already exist
    const existingUser = await User.findOne({ email });

    // If user exist return error
    if (existingUser) {
      return res
        .status(400)
        .send({ error: "User already exists. Please Login" });
    }

    // Encrypt user password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create user in our database
    const newUser = await User.create({
      firstName,
      lastName,
      userName,
      email: email.toLowerCase(),
      password: hashedPassword,
      age,
      gender,
    });

    // Create token using user id, email and secret
    const token = jwt.sign(
      { id: newUser._id, email: newUser.email },
      process.env.JWT_SECRET,
      {
        expiresIn: "2h",
      }
    );

    // return the token and user
    return res.status(201).json({
      user: newUser,
      token,
      message: "User created successfully",
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const login = async (req, res) => {
  try {
    // Get user input
    const { email, password } = req.body;

    // Validate user input
    if (!(email && password)) {
      res.status(400).send({ error: "All input is required" });
    }

    // Validate if user exist in our database
    const user = await User.findOne({ email });

    // If user exists and password is correct return token
    if (user && (await bcrypt.compare(password, user.password))) {
      const token = jwt.sign(
        { id: user._id, email: user.email },
        process.env.JWT_SECRET,
        {
          expiresIn: "2h",
        }
      );

      return res.status(200).json({
        user: user,
        token,
        message: "Login successful",
      });
    }

    // If user does not exist or password is incorrect return error
    return res.status(400).send({ error: "Invalid credentials" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const getUser = async (req, res) => {
  try {
    // find user in our database using id from token payload and miunus password
    const user = await User.findById(req.user.id).select("-password");

    // if user does not exist return error
    if (!user) {
      return res.status(400).send({ error: "User not found" });
    }
    // return user
    return res.status(200).json({
      user: user,
      message: "User found successfully",
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const updateUser = async (req, res) => {
  try {
    // find user in our database using id from token payload and miunus password
    const user = await User.findById(req.user.id).select("-password");

    // if user does not exist return error
    if (!user) {
      return res.status(400).send({ error: "User not found" });
    }

    // update user
    await User.findByIdAndUpdate(req.user.id, req.body);

    // find updated user
    const updatedUser = await User.findById(req.user.id).select("-password");

    // return updated user
    return res.status(200).json({
      user: updatedUser,
      message: "User updated successfully",
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const getUserById = async (req, res) => {
  try {
    // find user in our database using id from token payload and miunus password
    const user = await User.findById(req.params.id).select("-password");

    // if user does not exist return error
    if (!user) {
      return res.status(400).send({ error: "User not found" });
    }

    // return user
    return res.status(200).json({
      user: user,
      message: "User found successfully",
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

const getSuggestions = async (req, res) => {
  try {
    // suggestion feature which uses each users hobbies and information to narrow who is a good suggestion to other users.
    const loggedInUser = await User.findById(req.user.id).select("-password");
    // get the suggested users for the logged in user based on the hobbies, age, address, course
    // make a priority list of hobbies, age, address, course and then use $or to get the suggested users
    let suggestedUsers = await User.find({
      _id: { $ne: loggedInUser._id },
      $or: [
        { hobbies: { $in: loggedInUser.hobbies } },
        { age: { $in: loggedInUser.age } },
        { address: { $in: loggedInUser.address } },
        { course: { $in: loggedInUser.course } },
      ],
    }).select("-password");
    // now we need to suggested users based on the priority list of hobbies, age, address, course which has more things in common with the logged in user
    const newSuggestedUsers = suggestedUsers.map((user) => {
      let score = 0;
      // if the user has the same hobbies as the logged in user then add 1 to the score
      if (user.hobbies.some((hobby) => loggedInUser.hobbies.includes(hobby))) {
        score += 1;
      }
      // if the user has the same age as the logged in user then add 1 to the score
      if (user.age === loggedInUser.age) {
        score += 1;
      }
      // if the user has the same address as the logged in user then add 1 to the score
      if (user.address.includes(loggedInUser.address)) {
        score += 1;
      }
      // if the user has the same course as the logged in user then add 1 to the score
      if (user.course === loggedInUser.course) {
        score += 1;
      }
      return {
        ...user._doc,
        score,
      };
    });
    // sort the suggested users based on the score
    suggestedUsers = newSuggestedUsers.sort((a, b) => b.score - a.score);
    // if suggested users are more than 5 then slice the array to 5
    if (suggestedUsers.length > 5) {
      suggestedUsers = suggestedUsers.slice(0, 5);
    }
    // if the suggested users are less than 5 then add some random users to the list
    if (suggestedUsers.length < 5) {
      const randomUsers = await User.find({
        _id: { $nin: suggestedUsers.map((user) => user._id) },
      }).select("-password");
      // add random users to the suggested users list and the suggested users list should not exceed 5
      suggestedUsers.push(...randomUsers.slice(0, 5 - suggestedUsers.length));
    }
    // return suggested users
    return res.status(200).json({
      users: suggestedUsers,
      message: "Suggested users found successfully",
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// export all the functions
module.exports = {
  signup,
  login,
  getUser,
  updateUser,
  getUserById,
  getSuggestions,
};