const Post = require("../models/post-model");
const User = require("../models/user-model");

const createPost = async (req, res) => {
  try {
    // getting the url of the server
    const url = req.protocol + "://" + req.get("host");
    let image = "";
    // check if the user has uploaded an image
    if (req.file !== undefined) {
      image = url + "/uploads/" + req.file.filename;
    }
    // getting the user from the database
    const user = await User.findById(req.user.id).select("-password");
    // if the user is not found, then return an error
    if (!user) {
      return res.status(400).send({ error: "User not found" });
    }
    // creating a new post
    const post = await Post.create({
      text: req.body.text,
      image: image,
      user: req.user.id,
      likes: [],
      comments: [],
    });
    // returning the post
    return res.status(200).json({
      post: {
        _id: post._id,
        text: post.text,
        image: post.image,
        user: user,
        likes: post.likes,
        comments: post.comments,
      },
      message: "Post created successfully",
    });
  } catch (error) {
    // returning the error
    res.status(500).json({ error: error.message });
  }
};

const getAllPosts = async (req, res) => {
  try {
    // posts should be sorted by date, so that the latest post is at the top of the feed
    const posts = await Post.find()
      .populate("user", ["firstName", "lastName"])
      .populate("comments.user", ["firstName", "lastName"])
      .sort({ createdAt: -1 });
    // returning the posts
    return res.status(200).json({
      posts: posts,
      message: "Posts fetched successfully",
    });
  } catch (error) {
    // returning the error
    res.status(500).json({ error: error.message });
  }
};

const getUserPosts = async (req, res) => {
  try {
    // getting the user from the database
    const user = await User.findById(req.user.id).select("-password");
    // if the user is not found, then return an error
    if (!user) {
      return res.status(400).send({ error: "User not found" });
    }
    // posts should be sorted by date, so that the latest post is at the top
    const posts = await Post.find({ user: req.user.id })
      .populate("user", ["firstName", "lastName"])
      .populate("comments.user", ["firstName", "lastName"])
      .sort({ createdAt: -1 });
    // returning the posts
    return res.status(200).json({
      posts: posts,
      message: "Posts fetched successfully",
    });
  } catch (error) {
    // returning the error
    res.status(500).json({ error: error.message });
  }
};

const getPost = async (req, res) => {
  try {
    // getting the post from the database using the id from the request parameters and populating the user and comments
    const post = await Post.findById(req.params.id)
      .populate("user", ["firstName", "lastName"])
      .populate("comments.user", ["firstName", "lastName"]);
    // if the post is not found, then return an error
    if (!post) {
      return res.status(400).send({ error: "Post not found" });
    }
    // returning the post
    return res.status(200).json({
      post: post,
      message: "Post fetched successfully",
    });
  } catch (error) {
    // returning the error
    res.status(500).json({ error: error.message });
  }
};

const likePost = async (req, res) => {
  try {
    // getting the post from the database using the id from the request parameters and populating the user and comments
    const post = await Post.findById(req.params.id)
      .populate("user", ["firstName", "lastName"])
      .populate("comments.user", ["firstName", "lastName"]);
    // if the post is not found, then return an error
    if (!post) {
      return res.status(400).send({ error: "Post not found" });
    }
    // if the post is already liked by the user, then return an error
    if (
      post.likes.filter((like) => like.user.toString() === req.user.id).length >
      0
    ) {
      return res.status(400).send({ error: "Post already liked" });
    }
    // adding the user id to the likes array
    post.likes.unshift({ user: req.user.id });
    // saving the post
    await post.save();
    // returning the post
    return res.status(200).json({
      post: post,
      message: "Post liked successfully",
    });
  } catch (error) {
    // returning the error
    res.status(500).json({ error: error.message });
  }
};

const unlikePost = async (req, res) => {
  try {
    // getting the post from the database using the id from the request parameters and populating the user and comments
    const post = await Post.findById(req.params.id)
      .populate("user", ["firstName", "lastName"])
      .populate("comments.user", ["firstName", "lastName"]);
    // if the post is not found, then return an error
    if (!post) {
      return res.status(400).send({ error: "Post not found" });
    }
    // if the post is not liked by the user, then return an error
    if (
      post.likes.filter((like) => like.user.toString() === req.user.id)
        .length === 0
    ) {
      return res.status(400).send({ error: "Post has not yet been liked" });
    }
    // getting the index of the user id in the likes array
    const removeIndex = post.likes
      .map((like) => like.user.toString())
      .indexOf(req.user.id);
    // removing the user id from the likes array
    post.likes.splice(removeIndex, 1);
    // saving the post
    await post.save();
    // returning the post
    return res.status(200).json({
      post: post,
      message: "Post unliked successfully",
    });
  } catch (error) {
    // returning the error
    res.status(500).json({ error: error.message });
  }
};

const commentPost = async (req, res) => {
  try {
    // getting the post from the database using the id from the request parameters and populating the user and comments
    const post = await Post.findById(req.params.id)
      .populate("user", ["firstName", "lastName"])
      .populate("comments.user", ["firstName", "lastName"]);
    // if the post is not found, then return an error
    if (!post) {
      return res.status(400).send({ error: "Post not found" });
    }
    // getting the user from the database
    const user = await User.findById(req.user.id).select("-password");
    // if the user is not found, then return an error
    if (!user) {
      return res.status(400).send({ error: "User not found" });
    }
    // adding the user id and the comment to the comments array
    post.comments.unshift({
      user: req.user.id,
      text: req.body.text,
    });
    // saving the post
    await post.save();
    // getting the new post from the database and populating the user and comments
    const newPost = await Post.findById(req.params.id)
      .populate("user", ["firstName", "lastName"])
      .populate("comments.user", ["firstName", "lastName"]);

    // returning the new post
    return res.status(200).json({
      post: newPost,
      message: "Comment added successfully",
    });
  } catch (error) {
    // returning the error
    res.status(500).json({ error: error.message });
  }
};

const getUserPostsById = async (req, res) => {
  try {
    // getting the user from the database
    const user = await User.findById(req.params.id).select("-password");
    // if the user is not found, then return an error
    if (!user) {
      return res.status(400).send({ error: "User not found" });
    }

    // getting the posts from the database and populating the user and comments  and sorting them by the date they were created
    const posts = await Post.find({ user: req.params.id })
      .populate("user", ["firstName", "lastName"])
      .populate("comments.user", ["firstName", "lastName"])
      .sort({ createdAt: -1 });

    // returning the posts
    return res.status(200).json({
      posts: posts,
      message: "Posts fetched successfully",
    });
  } catch (error) {
    // returning the error
    res.status(500).json({ error: error.message });
  }
};

// exporting the functions

module.exports = {
  createPost,
  getAllPosts,
  getUserPosts,
  getPost,
  likePost,
  unlikePost,
  commentPost,
  getUserPostsById,
};
